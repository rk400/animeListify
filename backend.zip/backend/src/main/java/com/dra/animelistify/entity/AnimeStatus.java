package com.dra.animelistify.entity;

public enum AnimeStatus {
    PLAN_TO_WATCH,
    WATCHING,
    COMPLETED
}
